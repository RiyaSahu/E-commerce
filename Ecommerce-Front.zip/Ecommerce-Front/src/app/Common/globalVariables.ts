import { Cart } from "../component/cart/cart.component";

export class globalVariables{

    public cart:Cart[]=[];

}